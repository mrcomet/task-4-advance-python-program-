#!/usr/bin/env python
# coding: utf-8

# # Q1. Single Number

# In[ ]:


class Solution:
    def singleNumber(self, nums: List[int]) -> int:
        return 2 * sum(set(nums)) - sum(nums)

        


# # Q2. Sort Integers by The Number of 1 Bits

# In[ ]:


class Solution:
    def sortByBits(self, arr: List[int]) -> List[int]:
        return sorted(arr, key=self.getSortKey)
    
    def getSortKey(self, val):
        numOnes = 0
        currVal = val
        while currVal:
            numOnes += currVal % 2
            currVal >>= 1
        
        return (numOnes, val)


# # Q3. Single Number III

# In[ ]:


class Solution:
    def singleNumber(self, nums: List[int]) -> List[int]:
        x_xor_y = reduce(operator.xor, nums)
        bit =  x_xor_y & -x_xor_y
        result = [0, 0]
        for i in nums:
            result[bool(i & bit)] ^= i
        return result


# # Q4. Subset

# In[ ]:


class Solution:
    def subsets(self, nums: List[int]) -> List[List[int]]:
        results = []
        
        self.helper(results, nums, [], 0)
        
        return results
    
    def helper(self, results, nums, subset, start):
        results.append(list(subset))
        
        
        for i in range(start, len(nums)):
            num = nums[i]
            subset.append(num)
            self.helper(results, nums, subset, i + 1)
            subset.pop()
        

